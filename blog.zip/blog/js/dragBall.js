// JavaScript Document
//拖拽
function dragBall(obj,lastX,lastY,speedX,speedY,scrollball){
	obj.onmousedown=function(ev){
		var ev=ev || event;
				
			
		var disX=ev.clientX-obj.offsetLeft;
		var disY=ev.clientY-obj.offsetTop;
		obj.style.cursor='url(image/shubiao4.png),auto';
			
		if(obj.setCaptrue){
			obj.setCaptrue();
		}
			
		document.onmousemove=function(ev){
			var ev=ev||event;
					
			var L=ev.clientX-disX;
			var T=ev.clientY-disY;
			if(L<0){
				L=0;
			}else if(L>document.documentElement.clientWidth-obj.offsetWidth){
				L=document.documentElement.clientWidth-obj.offsetWidth;
			}
					
			if(T<0){
				T=0;
			}else if(T>document.documentElement.clientHeight-obj.offsetHeight){
				T=document.documentElement.clientHeight-obj.offsetHeight;
			}
				
			obj.style.left=L+'px';
			obj.style.top=T+'px';
			
			//用此时的位置减去上一次记录的位置，计算松开鼠标时碰撞运动开始的速度及方向
			speedX=L-lastX;
			speedY=T-lastY;
			//将此时的位置记录成上一次，用于下次计算
			lastX=L;
			lastY=T;
			
			return false;
		}
			
		document.onmouseup=function(){
			document.onmousemove=document.onmouseup=null;
			obj.style.cursor='url(image/shubiao3.png),auto';
			pz(obj,speedX,speedY,scrollball);
			if(obj.releaseCapture){
				obj.releaseCapture();
			}
		}
		clearInterval(obj.timer);
		return false;
	}
}


//运动
function pz(obj,speedX,speedY,scrollball){
	clearInterval(obj.timer);
	obj.timer=setInterval(function(){
		//每次运动都将竖直方向上的速度加大，模拟重力
		speedY+=3;
		//每次运动该到达的位置
		var l=obj.offsetLeft+speedX;
		var t=obj.offsetTop+speedY;
		//每次发生碰撞触发的条件，保证物体是在可视区运动
		if(t>=document.documentElement.clientHeight-obj.offsetHeight){
			//每次碰撞减小X和Y方向的速度，并将Y方向上的取反，达到反向运动的效果
			speedY*=-0.8;
			speedX*=0.8;
			//要越界时将物体直接放在边界位置
			t=document.documentElement.clientHeight-obj.offsetHeight;
		}else if(t<=0){
			speedY*=-1;
			speedX*=0.8;
			t=0;
		}
		if(l>=document.documentElement.clientWidth-obj.offsetWidth){
			//每次碰撞减小X方向的速度并取反，达到反向运动的效果
			speedX*=-0.8;
			l=document.documentElement.clientWidth-obj.offsetWidth;
		}else if(l<=0){
			speedX*=-0.8;
			l=0;
		}
		//在速度为0.几的负数时，物体还是会移动，因为舍弃小数，所以在速度很小时，将速度设置为0
		if(Math.abs(speedX)<1){
			speedX=0;	
		}
		if(Math.abs(speedY)<1){
			speedY=0;	
		}
		//运动终止条件，X、Y方向上速度都为0，并且是在最底部
		if(speedX==0&&speedY==0&&t==document.documentElement.clientHeight-obj.offsetHeight){
			clearInterval(obj.timer);	
		}else{
			//将每次运动该到达的位置给与物体
			if(speedX>0||speedX<0){
				scrollball +=speedX;
				obj.style.WebkitTransform='rotate('+scrollball+'deg)';
				obj.style.MozTransform='rotate('+scrollball+'deg)';
				obj.style.OTransform='rotate('+scrollball+'deg)';
				obj.style.MsTransform='rotate('+scrollball+'deg)';
			}
			obj.style.left=l+'px';
			obj.style.top=t+'px';
		}
	},30)
}