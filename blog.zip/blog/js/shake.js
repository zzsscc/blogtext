// JavaScript Document
//抖函数，n为最大抖动偏移，m为减震的幅度
function shake(obj,attr,n,m,endFn){
			if(obj.shaketimer){return};
			var pos=parseInt(getStyle(obj,attr));
			var num=0;
			var arr=[];
			var shaketimer=null;
				
			for(var i=n;i>0;i-=m){
				arr.push(i,-i);	
			}
			arr.push(0);
			
			clearInterval(obj.shaketimer);
			obj.shaketimer=setInterval(function(){
				obj.style[attr]=pos+arr[num]+'px';
				num++;
				if(num===arr.length){
					clearInterval(obj.shaketimer);
					obj.shaketimer=0;
					endFn && endFn();
				}
			}
			,50)
		}