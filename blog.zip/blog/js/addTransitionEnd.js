// JavaScript Document
function  addTransitionEnd(obj,fn){  
     obj.addEventListener('transitionEnd',fn,false);
     obj.addEventListener('transitionend',fn,false);
}
