// JavaScript Document
function  removeTransitionEnd(obj,fn){  
     obj.removeEventListener('transitionEnd',fn,false);
     obj.removeEventListener('transitionend',fn,false);
}
