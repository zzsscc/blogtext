// JavaScript Document
window.onload=function(){
	//球
	var ball=document.getElementById('ball');
	var speedX=Math.floor(Math.random()*(80-10+1)+10);
	var speedY=Math.floor(Math.random()*(80-10+1)+10);
	//声明并初始化，原始的相对位置，下面用来计算onmouseup的时候碰撞运动开始的速度和方向
	var lastX=0;
	var lastY=0;
	var scrollball=Math.floor(Math.random()*(180-0+1)+0);
	
	pz(ball,speedX,speedY,scrollball)
	dragBall(ball,lastX,lastY,0,0,scrollball);

	
	//时钟
	var oC=document.querySelector('#c1');
		var oGC=oC.getContext('2d');
		
		function toDraw(){
			var x=40;
			var y=40;
			var r=38;
			
			//每次执行前先清空画布
			oGC.clearRect(0,0,oC.width,oC.height);
			
			var oDate = new Date();
			var oHours = oDate.getHours();
			var oMin = oDate.getMinutes();
			var oSen = oDate.getSeconds();
			
			var oHoursValue = (-90 + oHours*30 + oMin/2) * Math.PI/180;
			var oMinValue = (-90 + oMin*6) * Math.PI/180;
			var oSenValue = (-90 + oSen*6) * Math.PI/180;
			
			
			//画小刻度及整个表盘
			oGC.beginPath();
			for(var i=0; i<60;i++){
				oGC.moveTo(x,y);
				oGC.arc(x,y,r,i*6*Math.PI/180,6*(i+1)*Math.PI/180,false);
			}
			oGC.closePath();
			oGC.stroke();
			
			//将中间部分用一个白色圆盘盖住,露出小刻度
			oGC.fillStyle='#fff';   //在方法内通用了，只要是填充，颜色就是白色
			oGC.beginPath();
			oGC.moveTo(x,y);
			oGC.arc(x,y,r*19/20,0,360*(i+1)*Math.PI/180,false);
			oGC.closePath();
			oGC.fill();
			
			//做大刻度
			oGC.save();
			oGC.lineWidth=2;
			oGC.beginPath();
			for(var i=0; i<12;i++){
				oGC.moveTo(x,y);
				oGC.arc(x,y,r,i*30*Math.PI/180,30*(i+1)*Math.PI/180,false);
			}
			oGC.closePath();
			oGC.stroke();
			oGC.restore();
			
			
			//将中间部分用一个白色圆盘盖住,露出大刻度
			oGC.beginPath();
			oGC.moveTo(x,y);
			oGC.arc(x,y,r*18/20,0,360*(i+1)*Math.PI/180,false);
			oGC.closePath();
			oGC.fill();
			
			
			//画时分秒针，（画一条直线的圆，设置其起始弧度=结束弧度）
			//秒针
			oGC.beginPath();
			oGC.moveTo(x,y);
			oGC.arc(x,y,r*18/20,oSenValue,oSenValue,false);
			oGC.closePath();
			oGC.stroke();
			
			//分针
			oGC.save();
			oGC.lineWidth=2;
			oGC.beginPath();
			oGC.moveTo(x,y);
			oGC.arc(x,y,r*14/20,oMinValue,oMinValue,false);
			oGC.closePath();
			oGC.stroke();
			oGC.restore();
			
			//时针
			oGC.save();
			oGC.lineWidth=4;
			oGC.beginPath();
			oGC.moveTo(x,y);
			oGC.arc(x,y,r*10/20,oHoursValue,oHoursValue,false);
			oGC.closePath();
			oGC.stroke();
			oGC.restore();
		}
		
		//加定时器每秒更新画布
		setInterval(toDraw,1000);
		
		toDraw();
	
	
	//分享栏
	//有兼容性问题oShareList.style.left=(document.documentElement.clientWidth-1200)/2-oShareList.offsetWidth+'px';
	var oShareList=document.getElementById('sharelist');
	var aShareLi=oShareList.getElementsByTagName('li');
	var aShareDiv=oShareList.getElementsByTagName('div');
	
	
	for(var i=0;i<aShareDiv.length;i++){
		aShareDiv[i].style.backgroundPosition=-30*i+'px 0px';
		if(i%2){
			aShareDiv[i].style.top=30+'px';
		}
	}
	
	for(var i=0;i<aShareLi.length;i++){
		aShareLi[i].onmouseover=function(){
			moveP(this.getElementsByTagName('div')[0],{top:-30},8)
			moveP(this.getElementsByTagName('div')[1],{top:0},8)
		}
		aShareLi[i].onmouseout=function(){
			moveP(this.getElementsByTagName('div')[0],{top:0},8)
			moveP(this.getElementsByTagName('div')[1],{top:30},8)
		}
	}
	
	
	//更多分享
	var oMoreShare=document.getElementById('moreshare');
	var aMoreSL=oMoreShare.getElementsByTagName('li');
	var iR=-150;
	var bOff=true;
	
	for(var i=0;i<aMoreSL.length;i++){
		aMoreSL[i].style.transition='0.2s';
		aMoreSL[i].style.backgroundPosition='-11px'+' -'+(43*i+13)+'px';
		aMoreSL[i].onclick=function(){
			this.style.transition='0.2s';
			this.style.transform='scale(2) rotate(720deg)';
			this.style.opacity='0.1';
			addTransitionEnd(this,end)
		}
	}
	function end(){
		this.style.transition='0.1s';
		this.style.transform='scale(1) rotate(720deg)';
		this.style.opacity='1';	
		removeTransitionEnd(this,end)
	}
	
	aShareLi[aShareLi.length-1].onclick=function(){
		if(bOff){
			for(var i=0;i<aMoreSL.length;i++){
				aMoreSL[i].style.transition='1s '+i*100+'ms';
				var oLT=toLT(iR,-(180/9*i+18))
				aMoreSL[i].style.left=oLT.l+'px';
				aMoreSL[i].style.top=oLT.t+'px';
				aMoreSL[i].style.transform='scale(1) rotate(720deg)';
			}
		}else{
			for(var i=0;i<aMoreSL.length;i++){
				aMoreSL[i].style.transition='1s '+(aMoreSL.length-i-1)*100+'ms';
				aMoreSL[i].style.left=0+'px';
				aMoreSL[i].style.top=0+'px';
				aMoreSL[i].style.transform='scale(1) rotate(0deg)';
			}
		}
		bOff=!bOff;
	}
	
	function toLT(iR,iDeg){
		return {l:Math.round(Math.sin(iDeg/180*Math.PI)*iR),t:Math.round(Math.cos(iDeg/180*Math.PI)*iR)};
	}
	
	
	//回到顶部
	var oTop=document.getElementById('totop');
	oTop.onmouseover=function(){
		this.style.backgroundPosition=-158+'px -16px';
		moveP(this,{bottom:0},8)
	}
	oTop.onmouseout=function(){
		if(parseInt(this.style.backgroundPosition)==-158){
		this.style.backgroundPosition=-33+'px -16px';
		moveP(this,{bottom:-57},8);
		}
	}
	oTop.onclick=function(){
		toTop1(oTop,function(){
			shake(oTop,'bottom',8,2,function(){
				toTop2(oTop,function(){
					toTop3(oTop,function(){
						//实现回到顶部功能
						document.documentElement.scrollTop = document.body.scrollTop = 0;
						oTop.style.backgroundPosition=-33+'px -16px';
						moveP(oTop,{bottom:-57},8);
					})	
				})
			})
		})
	}
	
	function toTop1(obj,endFn){
		clearInterval(obj.timer);
		obj.timer=setInterval(function(){
			obj.style.backgroundPosition=-661+'px -16px';
			endFn && endFn();
		},30)
	}
	function toTop2(obj,endFn){
		clearInterval(obj.timer);
		obj.timer=setInterval(function(){
			obj.style.backgroundPosition=-534+'px -16px';
			endFn && endFn();
		},30)
	}
	function toTop3(obj,endFn){
		clearInterval(obj.timer);
		obj.timer=setInterval(function(){
			obj.style.backgroundPosition=-409+'px -16px';
			endFn && endFn();
		},30)
	}
	
	
	//导航栏
	var oNavList=document.getElementById('navlist');
	var aNavLi=oNavList.getElementsByTagName('li');
	var aNavSpan=oNavList.getElementsByTagName('span');
	
	for(var i=0;i<aNavSpan.length;i++){
		aNavSpan[i].style.left=(aNavLi[i].offsetWidth-aNavSpan[i].offsetWidth)/2+'px';
	}
	
	for(var i=0;i<aNavLi.length;i++){
		aNavLi[i].style.width=aNavLi[i].offsetWidth;
		aNavLi[i].index=i;
		aNavLi[i].onmouseover=function(){
			moveP(aNavSpan[this.index],{top:25,opacity:100},8);
		}
		aNavLi[i].onmouseout=function(){
			moveP(aNavSpan[this.index],{top:6,opacity:0},8);
		}
		aNavLi[i].onclick=function(){
			open('../demo/building.html');
		}
	}
	
	//头部左侧的文字
	var oHeadList=document.getElementById('headlist');
	var aHeadLi=oHeadList.getElementsByTagName('li');
	var HLarr=['我们不停的翻弄着回忆','却再也找不回那时的自己','红尘一梦，不再追寻'];
	
	for(var i=0;i<aHeadLi.length;i++){
		aHeadLi[i].innerHTML=HLarr[i];
		aHeadLi[i].style.top=30+50*i+'px';
	}
	aHeadLi[0].timer=setTimeout(function(){
		moveP(aHeadLi[0],{left:400,opacity:100},25,function(){
			moveP(aHeadLi[1],{left:400,opacity:100},25,function(){
				aHeadLi[2].style.display='block';
				moveP(aHeadLi[2],{opacity:100},15);
			});	
		});
	},1000);
	
	
	//头像里的遮罩
	var oHp=document.getElementById('headpic');
	
	oHp.onmouseover=function(){
		moveP(this.getElementsByTagName('div')[0],{top:100},8);
	}
	oHp.onmouseout=function(){
		moveP(this.getElementsByTagName('div')[0],{top:150},8);
	}
	
	
	//@联系我
	var oWrap=document.getElementById('wrap');
	var aWrapP=oWrap.getElementsByTagName('p')[0];
	var aWrapDiv=oWrap.getElementsByTagName('div');
	var onOff=true;
	/*
	aWrapP.onmouseover=aWrapP.onmouseout=function(){
		this.classList.toggle('sun');
	}
	*/
	aWrapP.onclick=function(){
		runWrap(this);
	}
	function runWrap(obj){
		clearInterval(obj.timer);
		if(onOff){
			i=0;
			obj.timer=setInterval(function(){
				aWrapDiv[i].className='show';
				i++;
				if(i==aWrapDiv.length){
					clearInterval(obj.timer);
					onOff=false;
				}
			},150)
		}else{
			i=aWrapDiv.length-1;
			obj.timer=setInterval(function(){
				aWrapDiv[i].className='hidden';
				i--;
				if(i<0){
					clearInterval(obj.timer);
					onOff=true;
				}
			},150)
		}
	}
	
	
	//大轮播
	var carousel=document.getElementById('carousel');
	var cImg=carousel.getElementsByTagName('img')[0];
	var cUl=carousel.getElementsByTagName('ul')[0];
	var cLi=cUl.getElementsByTagName('li');
	var cDiv=carousel.getElementsByTagName('div');
	var num=0;
	
	function resize1(){
		cImg.style.top=(carousel.offsetHeight-cImg.offsetHeight)/2+'px'
		cImg.style.left=(carousel.offsetWidth-cImg.offsetWidth)/2+'px'
	}
	resize1();
	
	
	var cimgarr=['image/c1.jpg','image/c2.jpg','image/c3.jpg','image/c4.jpg'];
	lb(cImg);
	
	cDiv[0].style.left=(carousel.offsetWidth-cImg.offsetWidth)/2+'px';
	cDiv[1].style.right=(carousel.offsetWidth-cImg.offsetWidth)/2+'px';
	cDiv[0].onmouseover=function(){
		clearInterval(cImg.timer);
		ll();
	}
	cDiv[0].onmouseout=function(){
		moveP(this,{opacity:0},4)
	}
	cDiv[1].onmouseover=function(){
		clearInterval(cImg.timer);
		rr();
	}
	cDiv[1].onmouseout=function(){
		moveP(this,{opacity:0},4)
	}
	cDiv[0].onclick=function(){
		if(num==0){
			num=cimgarr.length-1;
			cImg.src=cimgarr[num];
			liqh(num)
		}else{
			num--;
			cImg.src=cimgarr[num];
			liqh(num)
		}
	}
	cDiv[1].onclick=function(){
		if(num==cimgarr.length-1){
			num=0;
			cImg.src=cimgarr[num];
			liqh(num)
		}else{
			num++;
			cImg.src=cimgarr[num];
			liqh(num)
		}
	}
	
	
	for(var i=0;i<cLi.length;i++){
		cLi[i].style.left=carousel.offsetWidth/2-90+40*i+'px';
		cImg.src=cimgarr[num];
		cLi[i].index=i;
		cLi[i].onclick=function(){
			clearInterval(cImg.timer);
			cImg.src=cimgarr[this.index];
			liqh(this.index);
			num=this.index;
			lb(cImg);
		}
	}


	cImg.onmousemove=function(ev){
		clearInterval(this.timer);
		var ev=ev||event;
		var L=ev.clientX;
		if(L<document.documentElement.clientWidth/2){
			ll();
		}else{
			rr();
		}
		
	}
	cImg.onmouseout=function(){
		moveP(cDiv[0],{opacity:0},4)
		moveP(cDiv[1],{opacity:0},4)
		lb(this);
	}
	
	function ll(){
		moveP(cDiv[1],{opacity:0},4)
		moveP(cDiv[0],{opacity:100},8)
	}
	function rr(){
		moveP(cDiv[0],{opacity:0},4)
		moveP(cDiv[1],{opacity:100},8)
	}

	
	function lb(obj){
		clearInterval(obj.timer);
		obj.timer=setInterval(ds,2000)
	}
	
	function qh(){
		cImg.src=cimgarr[num];
	}
	function liqh(n){
		for(var i=0;i<cLi.length;i++){
			cLi[i].classList.remove('active');
		}
		cLi[n].classList.add('active');
	}
	
	function ds(){
		if(num<cimgarr.length-1){
			num++;
			qh();
			liqh(num);
		}else{
			num=0;
			qh();
			liqh(num);
		}
	}
	
	//登录
	var wrap2=document.getElementById('wrap2');
	var login=document.getElementById('login');
	var loginSpan=login.getElementsByTagName('span')[0];
	
	wrap2.onmousemove=function(ev){
		var ev=ev||event;
		var L=document.documentElement.clientWidth-ev.clientX
		if(L>100){
			login.className="left";
		}else{
			login.className="right";
		}
	}
	wrap2.onmouseout=function(){
		login.className="";
	}
	
	loginSpan.onclick=function(){
		logDiv.style.display='block';
	}
	
	//登录窗口及蒙版
	var logDiv=document.getElementById('log');
	var mengban=logDiv.getElementsByTagName('div')[0];
	var toLog=logDiv.getElementsByTagName('div')[1];
	var logInput=toLog.getElementsByTagName('input');
	var toClose=toLog.getElementsByTagName('div')[0];
	var toForm=document.getElementById('tijiao');
	
	toClose.onclick=function(){
		logDiv.style.display='none';
		for(var i=0;i<logInput.length-1;i++){
			logInput[i].value='';
		}
	}
	toForm.onsubmit=function(){
		loginSpan.innerHTML='已登录';
		loginSpan.style.fontSize='24px'
		loginSpan.style.left='14px'
		loginSpan.style.top='40px'
		loginSpan.onclick=null;
		logDiv.style.display='none';
		return false;
	}
	
	//maintop
	var mtp=['随笔','致青春','Just about me'];
	var mtspan=['好久没发什么文章了。偶尔写几句话，表存在吧。努力学习。。fighting！！！','突然有一天我们会发现我们已经长大了,没有那童年时的天真,由饮料变成了啤酒由红领巾变成了领带,丢了我们那时候最可爱的纯真,没有曾经的那种快乐也没有曾经的那种执着,有的时候自己会莫名其妙的心情不好只想自己默默的发呆,发现自己身边的人都不了解自己面对身边的朋友不想说任何话有得时候突然想逃避生活逃避这一切因为有的时候我自己想哭都哭不出来,感觉自己一无所依被世界已经抛弃一样,我永远会感觉到孤单听到一首歌就会突然想起一个人一件事情,这一切的一切已经说明我们已经长大了,现在的我们开始背负着责任为了房子为了车子为了那所谓的爱情一直在奔波着奔波在不同的城市里每天的我们只能埋头苦干却不能对自己有任何怨言有的人在迷茫。迷茫自己的未来会怎么样迷漫自己会干些什么','我对茶情有独钟，买什么都喜欢带有淡淡的茶香味，在袅袅的茶气中，泡着茶，提壶、注水、出汤、品尝，自然平静，俨然与茶浑然一体。泡茶和 喝茶重要的是用心，只要用心，不一定是昂贵的茶叶，不一定要精雕细刻的茶具，也不需要复杂多变的手法，一样能够泡出清香四溢、韵味十足的好茶。若是感到心 烦意乱、孤独寂寞、茫然无助，就为自己泡茶。淡而入心，唯有茶也……'];
	
	var maintop=document.getElementById('maintop');
	var maintDiv=maintop.getElementsByTagName('div')[0];
	var maintLi=maintDiv.getElementsByTagName('li');
	var maintP=maintDiv.getElementsByTagName('p');
	var maintSpan=maintDiv.getElementsByTagName('span');

	
	for(var i=0;i<maintLi.length;i++){
		var mp=document.createElement('p');
		var mspan=document.createElement('span');
		maintLi[i].index=i;
		maintLi[i].appendChild(mp);
		maintLi[i].appendChild(mspan);
		maintLi[i].onmouseover=function(){
			moveP(this,{opacity:50},8);
			maintP[this.index].style.color='black';
			maintSpan[this.index].style.textShadow='1px 1px 2px rgba(0,0,0,0.5)';
		}
		maintLi[i].onmouseout=function(){
			moveP(this,{opacity:100},8);
			maintP[this.index].style.color='#EF7000';
			maintSpan[this.index].style.textShadow='';
		}
		maintLi[i].onclick=function(){
			open('../demo/building.html');
		}
	}
	for(var i=0;i<maintP.length;i++){
		maintP[i].innerHTML=mtp[i];
		maintSpan[i].innerHTML=mtspan[i];
	}
	
	
	
	//mainpage
	var mainpage=document.getElementById('mainpage');
	var mainpDiv=mainpage.getElementsByTagName('div');
	var mainpre=mainpage.getElementsByTagName('pre');
	var readarr=getElementsByClassName(mainpage,'a','read');
	
	for(var i=0;i<readarr.length;i++){
		readarr[i].index=i;
		readarr[i].onclick=function(){
			var that=this;
			var readarrHTML=this.innerHTML.slice(0,2);
			if(readarrHTML==='阅读'){
				moveP(mainpre[this.index],{height:400},15,function(){
					readarr[that.index].innerHTML='收起>>';
				});
			}else{
				moveP(mainpre[this.index],{height:100},15,function(){
					readarr[that.index].innerHTML='阅读全文>>';
				});
			}
		}
		readarr[readarr.length-1].onclick=function(){
			var that=this;
			var readarrHTML=this.innerHTML.slice(0,2);
			if(readarrHTML==='阅读'){
				moveP(mainpre[this.index],{height:600},15,function(){
					readarr[that.index].innerHTML='收起>>';
				});
			}else{
				moveP(mainpre[this.index],{height:100},15,function(){
					readarr[that.index].innerHTML='阅读全文>>';
				});
			}
		}
		
	}
	
	//mainside news
	var news=document.getElementById('news');
	var newsLi=news.getElementsByTagName('li');
	
	for(var i=0;i<newsLi.length;i++){
		newsLi[i].style.backgroundPosition='10px'+' -'+(40*i)+'px';
	}
	
	//mainside comment
	var comment=document.getElementById('comment');
	var commentDiv=comment.getElementsByTagName('div')[0];
	var commentUl=comment.getElementsByTagName('ul')[0];
	var commentLi=comment.getElementsByTagName('li');
	var wfgdspeed=-2;
	
	for(var i=0;i<commentLi.length;i++){
		commentLi[i].style.backgroundPosition='0'+' -'+(80*i)+'px';
	}
	
	var commentLiHTML=commentUl.innerHTML;
	commentUl.innerHTML+=commentLiHTML;
	commentUl.style.Height=commentLi.length*commentLi[0].offsetHeight+'px';
	var W=commentUl.offsetHeight/2-10;
	wfgddsq(commentUl)
	
	
	function wfgd(){
		if(Math.abs(commentUl.offsetTop) >= W){
			commentUl.style.top=0;
		}
		commentUl.style.top=commentUl.offsetTop+wfgdspeed+'px';
	}
	
	function wfgddsq(obj){
		obj.timer=setInterval(wfgd,30)
	}
	
	commentDiv.onmouseover=function(){
		clearInterval(commentUl.timer);
	}
	commentDiv.onmouseout=function(){
		wfgddsq(commentUl);
	}
	
	
	
	
	//百度统计
	var record=document.getElementById('record');
	var recordp=record.getElementsByTagName('p')[0];
	var statistics=record.getElementsByTagName('img')[0];
	function resize2(){
		recordp.style.top=(record.offsetHeight-recordp.offsetHeight)/2+'px'
		recordp.style.left=(record.offsetWidth-recordp.offsetWidth)/2-statistics.offsetWidth+'px'
		statistics.style.left=recordp.offsetLeft+recordp.offsetWidth+10+'px'
	}
	resize2();
	window.onresize=function(){
		resize1();
		resize2();
	}
}