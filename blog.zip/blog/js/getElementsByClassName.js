// JavaScript Document
//通过classname获取一组元素
function getElementsByClassName(parent,tagN,classN){
     var aEls = parent.getElementsByTagName(tagN);
     var arr=[];
	 var re=new RegExp('\\b'+classN+'\\b','i');         //正则表达式，\b单词边界，规定classN必须是前后必须是单词边界

     for( var i=0;i<aEls.length;i++ ){
		 if(re.test(aEls[i].className)){
			arr.push(aEls[i]);	 
		 }
     }
     return arr;
}


//---调用时tagN（指定获取的标签名）和classN（指定获取的className）要加引号(oUL,'li','li1')
