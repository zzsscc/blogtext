// JavaScript Document
//获取元素的指定的样式
function getStyle(obj,attr){
	return obj.currentStyle? obj.currentStyle[attr]:getComputedStyle(obj,false)[attr];
}
			
//调用时attr需要加引号，getStyle(oDiv,'left');