// JavaScript Document
//全部完成才停止
function moveP(obj,json,ispeed,fn){
	clearInterval(obj.timer);
	obj.timer=setInterval(function(){
		var bStop=true;       //所有值都完成
		for(var attr in json){
			//取当前的值
			var iCur=0;
			if(attr=='opacity'){
				iCur=parseInt(parseFloat(getStyle(obj,attr))*100);
			}else{
				iCur=parseInt(getStyle(obj,attr));
			}
			//计算速度
			var speed=(json[attr]-iCur)/ispeed;
			speed=speed>0?Math.ceil(speed):Math.floor(speed);
			//检测停止
			if(iCur!=json[attr]){
				bStop=false;	
			}
			if(attr=='opacity'){
				obj.style.filter='alpha(opacity:'+(iCur+speed)+')';
				obj.style.opacity=(iCur+speed)/100;
			}else{
				obj.style[attr]=iCur+speed+'px';
			}
		}
		
		if(bStop){
			clearInterval(obj.timer);
			if(fn){
				fn();
			}	
		}
	},30);
}
//调用如
//moveP(oDiv,{width:300,height:200,opacity:100},8);